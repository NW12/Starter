# react-starter-cli
the command line tool for building react-starter project quickly


## Usage: 

```
$ git clone git@github.com:blackLearning/react-starter-cli.git && npm install 
$ npm link
$ react-cli --help
```

> ready to go !